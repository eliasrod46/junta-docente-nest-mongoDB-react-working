import { onInputChange } from "./handlerLogicFunction.js";
// input chande handler
import { InputText } from "primereact/inputtext";
import {
  saveTeacherHandler,
  deleteTeacherFuction,
} from "./handlerLogicFunction.js";
import {
  hideElementModal,
  hideDeleteElementModal,
} from "./handlerModalFunction.js";
import {
  DangerButton,
  SuccessButton,
  InfoButton,
} from "../../../../../components/Buttons.jsx";

//====================>Header Table(Global Search)
export const tableHeader = (setGlobalFilter) => {
  return (
    <div className="flex flex-col align-items-center p-2 text-right">
      <h4 className="text-md">Buscar Docente:</h4>
      <span>
        <InputText
          className="text-md p-1 rounded-lg"
          type="search"
          onInput={(e) => setGlobalFilter(e.target.value)}
          placeholder="Buscar..."
        />
      </span>
    </div>
  );
};

//====================>footer Modals

//-- add/update Element
export const elementModalFooter = (
  element,
  toEdit,
  setToEdit,
  setErrors,
  setElement,
  emptyElement,
  setElementModal,
  toast,
  saveTitle, // CAMBIAR
  getAllTitles // CAMBIAR
  // updateTeacher // CAMBIAR
) => {
  return (
    <>
      <DangerButton clickHandler={() => hideElementoModal(setTeacherDialog)}>
        Cancelar
      </DangerButton>
      <SuccessButton
        clickHandler={() =>
          saveTeacherHandler(
            teacher,
            toEdit,
            setToEdit,
            saveTeacher,
            setErrors,
            getAllTeachers,
            setTeacherDialog,
            setTeacher,
            emptyTeacher,
            updateTeacher,
            toast
          )
        }
      >
        Guardar
      </SuccessButton>
    </>
  );
};

//-- delete Element
export const deleteElementModalFooter = (
  teacher,
  deleteTeacher,
  getAllTeachers,
  setTeacher,
  setDeleteTeacherDialog,
  emptyTeacher,
  toast
) => {
  // buttons to delete
  return (
    <div className="pt-5">
      <InfoButton
        clickHandler={() => hideDeleteElementModal(setDeleteTeacherDialog)}
      >
        No
      </InfoButton>
      <DangerButton
        clickHandler={() =>
          deleteTeacherFuction(
            teacher,
            deleteTeacher,
            getAllTeachers,
            setTeacher,
            setDeleteTeacherDialog,
            emptyTeacher,
            toast
          )
        }
      >
        Si
      </DangerButton>
    </div>
  );
};

//====================>Modals Components

export const InputModal = ({ id, element, setElement }) => {
  return (
    <InputText
      id={id}
      value={element[id]}
      onChange={(e) => onInputChange(e, id, element, setElement)}
      required
      autoFocus
      className="text-md p-1 rounded-lg"
    />
  );
};

export const ShowErrors = ({ id, errors }) => {
  return (
    <ul>
      {errors.map((error, i) => {
        return (
          error.path === id && (
            <li key={i}>
              <small className="text-red-500 font-bold text-md">
                * {error.msg}
              </small>
            </li>
          )
        );
      })}
    </ul>
  );
};

export const LabelModal = ({ id, label }) => {
  return (
    <label htmlFor={id} className="font-bold block">
      {label}
    </label>
  );
};
