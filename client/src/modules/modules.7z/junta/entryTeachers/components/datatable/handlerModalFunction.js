//====>opemn modals Handler

//---open modal to create
export const ShowCreateElementModal = (
  setTeacher,
  setTeacherDialog,
  emptyTeacher
) => {
  // save teacher empty
  setTeacher(emptyTeacher);
  // set submitted in false
  // setSubmitted(false);
  // open modal
  setTeacherDialog(true);
};

//---open modal to edit
export const ShowEditElementModal = (
  teacher,
  setTeacher,
  setToEdit,
  setTeacherDialog
) => {
  // save teacher in template
  setTeacher({ ...teacher });
  setToEdit(true);
  // open modal
  setTeacherDialog(true);
};

//---open modal to delete
export const ShowConfirmDeleteElement = (
  teacher,
  setTeacher,
  setDeleteTeacherDialog
) => {
  setTeacher(teacher);
  setDeleteTeacherDialog(true);
};

//====>reset modal Handler
// close modal create | edit
export const hideElementModal = (setTeacherDialog) => {
  setTeacherDialog(false);
};

// close modal delete
export const hideDeleteElementModal = (setDeleteTeacherDialog) => {
  setDeleteTeacherDialog(false);
};
