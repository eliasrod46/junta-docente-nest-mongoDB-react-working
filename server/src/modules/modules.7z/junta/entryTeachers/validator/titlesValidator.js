import { check } from "express-validator";
import { validateResult } from "../../../../helpers/validateHelper.js";

export const validateTitle = [
  check("name")
    .notEmpty()
    .withMessage("no vacio")
    .isString()
    .withMessage("string")
    .isLength({ min: 3, max: 30 })
    .withMessage("cadena minimo 3, maximo 30"),

  check("short_name")
    .notEmpty()
    .withMessage("no vacio")
    .isString()
    .withMessage("string")
    .isLength({ min: 3, max: 30 })
    .withMessage("cadena minimo 3, maximo 30"),

  (req, res, next) => {
    validateResult(req, res, next);
  },
];
