import { Title } from "../models/titleModel.js";

const titles = [
  { name: "Bachiller Commun", short_name: "bach" },
  { name: "Profesorado de Educacion Primaria", short_name: "prof.prim.com" },
  {
    name: "Capacitacion de Educacion Especial",
    short_name: "capacitacion.ee",
  },
];

export async function titlesSeed() {
  titles.forEach(async function (title) {
    await Title.create({
      name: title.name,
      short_name: title.short_name,
    });
  });
}
