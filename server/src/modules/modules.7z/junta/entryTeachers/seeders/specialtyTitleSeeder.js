import { SpecialtyTitle } from "../models/SpecialtyTitleModel.js";

const Specialtestitles = [
  { title_id: 1, specialty_id: 1 },
  { title_id: 1, specialty_id: 2 },
  { title_id: 2, specialty_id: 2 },
  { title_id: 1, specialty_id: 3 },
];

export async function specialtiesTitlesSeed() {
  Specialtestitles.forEach(async function (specialty) {
    await SpecialtyTitle.create({
      title_id: specialty.title_id,
      specialty_id: specialty.specialty_id,
    });
  });
}
