import { Specialty } from "../models/specialtiesModel.js";

const specialties = [
  { name: "Maestro de Grado", short_name: "MG-COM" },
  { name: "Maestro Celador", short_name: "MC-COM" },
  { name: "Celador", short_name: "CEL-COM" },
];

export async function specialtiesSeed() {
  specialties.forEach(async function (specialty) {
    await Specialty.create({
      name: specialty.name,
      short_name: specialty.short_name,
    });
  });
}
