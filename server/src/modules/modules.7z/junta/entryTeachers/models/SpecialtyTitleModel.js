//import conection
import { db } from "../../../../database/db.js";
import { DataTypes } from "sequelize";
//import models
import { Specialty } from "./specialtiesModel.js";
import { Title } from "./titleModel.js";

export const SpecialtyTitle = db.define("specialty_title", {
  title_id: { type: DataTypes.BIGINT, allowNull: true },
  specialty_id: { type: DataTypes.BIGINT, allowNull: true },
});

export const SpecialtyTitleMigration = async () => {
  await SpecialtyTitle.sync({ force: true });

  Title.belongsToMany(Specialty, { through: "specialty_title" });
  Specialty.belongsToMany(Title, { through: "specialty_title" });

  console.log("The table for the specialty_title model was just (re)created!");
};
