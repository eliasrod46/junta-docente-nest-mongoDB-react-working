//import conection
import { db } from "../../../../database/db.js";
import { DataTypes } from "sequelize";
//import models

export const Specialty = db.define("specialties", {
  name: { type: DataTypes.STRING, allowNull: false },
  short_name: { type: DataTypes.STRING, allowNull: false },
});

export const SpecialtyMigration = async () => {
  await Specialty.sync({ force: true });
  console.log("The table for the Specialty model was just (re)created!");
};
