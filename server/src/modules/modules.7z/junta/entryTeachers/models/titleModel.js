//import conection
import { db } from "../../../../database/db.js";
import { DataTypes } from "sequelize";
//import models
import { Specialty } from "./specialtiesModel.js";

export const Title = db.define("titles", {
  name: { type: DataTypes.STRING, allowNull: false },
  short_name: { type: DataTypes.STRING, allowNull: false },
});

export const TitleMigration = async () => {
  await Title.sync({ force: true });

  console.log("The table for the Title model was just (re)created!");
};
