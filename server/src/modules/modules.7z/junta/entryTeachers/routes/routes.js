// base "/api"

import { Router } from "express";
import { router as shiftsRoutes } from "./shifts.routes.js";
import { router as titlesRoutes } from "./titles.routes.js";
import { router as specialtiesRoutes } from "./specialties.routes.js";
export const router = Router();

router.use("/turnos", shiftsRoutes);
router.use("admin/titles", titlesRoutes);
router.use("admin/specialties", specialtiesRoutes);
