// base "/api/admin/specialties"

import { Router } from "express";
import { validateSpecialty } from "../validator/specialtyValidator.js";
import { specialtiesController } from "../controllers/specialtiesController.js";

export const router = Router();

router.get("/", specialtiesController.getAll);
router.post("/", validateSpecialty, specialtiesController.create);
