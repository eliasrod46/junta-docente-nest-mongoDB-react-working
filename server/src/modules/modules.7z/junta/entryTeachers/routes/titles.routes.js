// base "/api/admin/titles"

import { Router } from "express";
import { validateTitle } from "../validator/titlesValidator.js";
import { titlesController } from "../controllers/titlesController.js";

export const router = Router();

router.get("/", titlesController.getAll);
router.post("/", validateTitle, titlesController.create);
