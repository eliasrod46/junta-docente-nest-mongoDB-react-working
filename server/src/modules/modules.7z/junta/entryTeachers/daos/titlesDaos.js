import { Title } from "../models/titleModel.js";

class TitlesDao {
  async addElement({ name, short_name }) {
    try {
      await Title.create({ name, short_name });
    } catch (error) {
      console.log({ message: error.message });
      return undefined;
    }
  }

  async getAllElements() {
    try {
      const titles = await Title.findAll();
      return titles;
    } catch (error) {
      console.log({ message: error.message });
      return [];
    }
  }
}
export const titlesDao = new TitlesDao();
