import { Specialty } from "../models/specialtiesModel.js";

class SpecialtiesDao {
  async addElement({ name, short_name }) {
    try {
      await Specialty.create({ name, short_name });
    } catch (error) {
      console.log({ message: error.message });
      return undefined;
    }
  }

  async getAllElements() {
    try {
      const titles = await Specialty.findAll();
      return titles;
    } catch (error) {
      console.log({ message: error.message });
      return [];
    }
  }
}
export const specialtiesDao = new SpecialtiesDao();
