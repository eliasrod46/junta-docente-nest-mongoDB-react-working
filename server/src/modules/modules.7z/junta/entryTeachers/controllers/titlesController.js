import { titlesDao } from "../daos/titlesDaos.js";

class TitlesController {
  async getAll(req, res) {
    try {
      const titles = await titlesDao.getAllElements();
      res
        .status(201)
        .json({ message: "success, sending all teachers", data: titles });
    } catch (error) {
      console.log({ error: error.message });
    }
  }

  async create(req, res) {
    const { name, short_name } = req.body;
    try {
      await titlesDao.addShift({ name, short_name });
      res.status(201).json({ success: "Title created succesfull" });
    } catch (error) {
      //send something
      console.log({ error: error.message });
    }
  }
}

export const titlesController = new TitlesController();
