import { specialtiesDao } from "../daos/specialtiesDaos.js";

class SpecialtiesController {
  async getAll(req, res) {
    try {
      const specialties = await specialtiesDao.getAllElements();
      res
        .status(201)
        .json({ message: "success, sending all teachers", data: specialties });
    } catch (error) {
      console.log({ error: error.message });
    }
  }

  async create(req, res) {
    const { name, short_name } = req.body;
    try {
      await specialtiesDao.addShift({ name, short_name });
      res.status(201).json({ success: "Title created succesfull" });
    } catch (error) {
      //send something
      console.log({ error: error.message });
    }
  }
}

export const specialtiesController = new SpecialtiesController();
