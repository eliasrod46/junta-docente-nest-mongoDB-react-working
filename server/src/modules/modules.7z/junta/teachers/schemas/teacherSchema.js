export const createTeacheSchema = {
  name: {
    isLength: {
      options: { min: 3 },
      errorMessage: "name should be at least 3 chars",
    },
    trim: true,
    isEmail: true,
  },
  lastname: {
    trim: true,
    isLength: {
      options: { min: 3 },
      errorMessage: "lastname should be at least 3 chars",
    },
  },
  dni: {
    isInt: {
      errorMessage: "dni should be a number",
    },
  },
};
